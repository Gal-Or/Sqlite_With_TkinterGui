class Filter:

    def __init__(self, attribute, operator, attr_type, value=""):
        self.attr_type = attr_type
        self.attribute = attribute

        if "NVARCHAR" in attr_type:
            self.value = "\'" + value + "\'"
            if operator == '=':
                self.operator = 'LIKE'
            elif operator == '!=':
                self.operator = 'NOT LIKE'
            else:
                self.operator = operator
        else:
            self.operator = operator
            self.value = value

    def __str__(self):
        return self.attribute + " " + self.operator + " " + str(self.value)
