from tkinter import *
from tkinter import ttk
from tkinter import colorchooser
import sqlite3
from My_Filter import Filter
from My_Manager import Manager

global mycursor
global table_name
type_dict = {}

manager = Manager()
root = Tk()
width_val = root.winfo_screenwidth()
height_val = root.winfo_screenheight()
root.geometry("%dx%d" % (width_val, height_val))
root.title("Tables")

top_frame = Frame(root)
table_frame = Frame(root)
title_list_frame = Frame(root)
listbox_frame = Frame(root)
btns_frame = Frame(root)
query_frame = Frame(root)

var = IntVar()

values = ["albums", "artists", "customers", "employees", "genres", "invoice_items"]
operators = ["=", "!=", ">", "<", ">=", ">=", "IN", "IS NULL", "IS NOT NULL"]
style = ttk.Style()
# Pick a theme
style.theme_use("clam")
# configure out tree view  style
style.configure("Treeview",
                background="white",
                foreground="black",
                rowheight=25,
                fieldbackground="white")
# Change selected color
style.map('Treeview', background=[('selected', '#ffc0b4')])


def clear_table():
    # delete the old table
    for child in table_frame.winfo_children():
        child.destroy()


def clear_btns():
    # delete the old table
    for child in btns_frame.winfo_children():
        child.destroy()


def clear_title_list():
    # delete the old table
    for child in title_list_frame.winfo_children():
        child.destroy()


def clear_filters():
    # delete filters frame
    for child in listbox_frame.winfo_children():
        child.destroy()


def clear_query():
    # delete query frame
    for child in query_frame.winfo_children():
        child.destroy()


def create_table(query_str, clear=False):
    clear_table()
    clear_title_list()
    # clear_btns()
    clear_query()

    if clear:
        clear_filters()

    # create vertical scrollbar
    tree_v_scroll = Scrollbar(table_frame, orient="vertical")
    tree_v_scroll.pack(side=RIGHT, fill=Y)
    # create horizontal scrollbar
    tree_h_scroll = Scrollbar(table_frame, orient="horizontal")
    tree_h_scroll.pack(side=BOTTOM, fill=X)

    # connecting to chinook
    conn = sqlite3.connect('chinook.db')
    global mycursor
    mycursor = conn.cursor()

    mycursor.execute(query_str)

    # get all columns names
    columns_names = list(map(lambda xx: xx[0], mycursor.description))

    # create the tree view
    tree = ttk.Treeview(table_frame, columns=columns_names, height=10, show="headings",
                        yscrollcommand=tree_v_scroll.set, xscrollcommand=tree_h_scroll.set,
                        style="mystyle.Treeview")
    tree.tag_configure('oddrow', background='#eaeaea')
    tree.tag_configure('evenrow', background='#fdf3f1')

    tree.pack(side='top')

    # set scrollbars configuration
    tree_v_scroll.config(command=tree.yview)
    tree_h_scroll.config(command=tree.xview)

    # add data to the tree
    for name in columns_names:
        tree.heading(name, text=name)

    for name in columns_names:
        tree.column(name)

    for x in tree.get_children():
        tree.delete(x)

    count = 0
    results = mycursor.fetchall()
    for row in results:
        if count % 2 == 0:
            tree.insert('', 'end', values=row[0:len(columns_names)], tags='evenrow')
        else:
            tree.insert('', 'end', values=row[0:len(columns_names)], tags='oddrow')
        count += 1

    s = ttk.Style()
    s.theme_use('clam')
    s.configure('Treeview.Heading', background="#ffc0b4")

    create_title_list_frame()
    if clear:
        create_listbox_frame()

    conn.close()


def create_title_list_frame():
    title = Label(title_list_frame, text="Chosen Filters:", font=('bold', 12))
    title.pack(side=TOP)


def create_listbox_frame():
    # create scrollbar to the listbox
    listbox_scrollbar = Scrollbar(listbox_frame, orient=VERTICAL)

    # create filters list
    filters_list = Listbox(listbox_frame, height=10,
                           width=50,
                           bg="#e5e5e5",
                           activestyle='dotbox',
                           selectbackground="black",
                           yscrollcommand=listbox_scrollbar.set)

    # configure scrollbar
    listbox_scrollbar.config(command=filters_list.yview)

    listbox_scrollbar.pack(side=RIGHT, fill=Y)
    filters_list.pack(side=TOP)

    create_btns_frame(filters_list)


def create_btns_frame(filters_list):
    # create "add filter" btn
    add_filter_btn = Button(btns_frame, text="Add Filter", width=10, bd='5', command=add_query)
    # create "delete_filter" btn
    delete_filter_btn = Button(btns_frame, text="Delete Filter", width=10, bd='5',
                               command=lambda: delete_filter(filters_list,var))
    # create "case sensitive" checkbox
    # var = IntVar() ---> define outside
    case_sens_check = Checkbutton(btns_frame, text="case sensitive", variable=var)

    # add_filter_btn.pack(side=LEFT, pady=10, padx=10)
    # delete_filter_btn.pack(side=RIGHT, pady=10, padx=5)
    # case_sens_check.pack(side=BOTTOM, pady=10)

    add_filter_btn.grid(row=0, column=0, padx=5)
    delete_filter_btn.grid(row=0, column=1, padx=5)
    case_sens_check.grid(row=0, column=2, padx=5)


def delete_filter(filters_list,is_sensitive):
    x = filters_list.curselection()
    if x:  # checks if the tuple is not empty -> can be empty when click on delete without select item in the list box
        manager.remove(manager.all_filters[filters_list.curselection()[0]])
        filters_list.delete(ANCHOR)
        build_query(is_sensitive)


def get_upper_query(filter):
    return "UPPER(" + filter.__getattribute__("attribute") + ") " + filter.__getattribute__(
        "operator") + " UPPER(" + filter.__getattribute__("value") + ") "


def build_query(is_sensitive):
    global table_name
    query = "SELECT *  FROM " + table_name
    if len(manager.all_filters) > 0:
        query += " WHERE "
    size = len(manager.all_filters)
    i = 0
    for filter in manager.all_filters:
        if is_sensitive:
            query += get_upper_query(filter)
        else:
            query += str(filter)

        if i < size - 1:
            query += " AND "
        i += 1

    print(query + "\n")
    create_table(query)


def submit_action(attr, op, is_sensitive, val=""):
    # check the input..
    add_to_listbox(attr, op, val)

    build_query(is_sensitive)


# creates a new frame to new query
def add_query():
    clear_query()
    global mycursor
    # get all columns names
    columns_names = list(map(lambda xx: xx[0], mycursor.description))
    combo_attr = create_combobox(query_frame, columns_names, 0, 0)
    combo_op = create_combobox(query_frame, operators, 0, 1)

    combo_op.bind("<<ComboboxSelected>>", lambda event: callback_choose_op(event, combo_attr.get()))


def add_to_listbox(attr, op, val):  # on submit pressed
    new_filter = Filter(attr, op, type_dict[attr], val)
    list_size = len(manager.all_filters)
    manager.add_filter(new_filter)
    if list_size < len(manager.all_filters):
        listbox_frame.winfo_children()[1].insert(END, new_filter.__str__())
    clear_query()


def create_combobox(frame, vals, r, c):
    combo_tables = ttk.Combobox(frame, values=vals)
    combo_tables.grid(row=r, column=c, padx=10)
    return combo_tables


def init_dict():
    # connecting to chinook
    conn = sqlite3.connect('chinook.db')
    global mycursor
    mycursor = conn.cursor()

    global table_name
    mycursor.execute("PRAGMA table_info(" + table_name + ")")
    info = mycursor.fetchall()

    for col in info:
        type_dict[col[1]] = col[2]

    print(type_dict.items())
    conn.close()


def callback_choose_table(event):
    type_dict.clear()
    # connecting to chinook
    conn = sqlite3.connect('chinook.db')
    global mycursor
    mycursor = conn.cursor()

    manager.all_filters = []
    global table_name
    clear_filters()
    table_name = event.widget.get()
    # create query string and execute it
    query_str = "SELECT *  FROM " + table_name
    init_dict()
    create_table(query_str, True)


def callback_choose_op(event, attr):
    all_widgets = query_frame.winfo_children()
    for widget in all_widgets:
        if str(widget.__class__) == "<class 'tkinter.Entry'>" or str(widget.__class__) == "<class 'tkinter.Button'>":
            widget.destroy()

    op_val = event.widget.get()
    if op_val != "IS NULL" and op_val != "IS NOT NULL":
        input_txt = Entry(query_frame)
        input_txt.grid(row=0, column=2, padx=10)
        # create "submit" btn
        submit_btn = Button(query_frame, text="Submit", bd='5',
                            command=lambda: submit_action(attr, op_val, var.get(), input_txt.get()))
    else:
        # create "submit" btn
        submit_btn = Button(query_frame, text="Submit", bd='5',
                            command=lambda: submit_action(attr, op_val, var.get()))

    submit_btn.grid(row=1, column=1, pady=10)
    all_widgets = query_frame.winfo_children()
    print("all widget: \n")
    for widget in all_widgets:
        print(str(widget.__class__) + "\n")
    print("---------------\n")


def main():
    root.wm_attributes("-topmost", 1)

    top_frame.pack(padx=10, pady=10)

    lbl_title = Label(top_frame, text="Choose Table : ", font=('bold', 12), pady=10, padx=10)
    lbl_title.grid(row=0, column=0)

    combo_tables = create_combobox(top_frame, values, 0, 1)

    table_frame.pack(padx=100, pady=10)
    title_list_frame.pack(padx=100, pady=5)
    listbox_frame.pack(padx=10, pady=10)
    btns_frame.pack(padx=10, pady=10)
    query_frame.pack(padx=10, pady=10)

    combo_tables.bind("<<ComboboxSelected>>", callback_choose_table)

    root.mainloop()


main()
