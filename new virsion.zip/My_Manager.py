import My_Filter


class Manager:
    def __init__(self):
        self.all_filters = []

    def add_filter(self, new_filter):
        if self.check_if_exist(new_filter) == -1:
            self.all_filters.append(new_filter)

    def check_if_exist(self, new_filter):
        for f in self.all_filters:
            if f.attribute == new_filter.attribute and f.operator == new_filter.operator and f.value == new_filter.value:
                return self.all_filters.index(f)

        return -1

    def remove(self, f):
        index = self.check_if_exist(f)
        if index != -1:
            self.all_filters.remove(f)

    def __str__(self):
        str = "All Filters: \n"
        for f in self.all_filters:
            str += f.__str__() + "\n"
        return str
